import $ from "jquery";

$(document).ready(function () {
  $("#order_now").click(function () {
    window.location.href = "/order";
  });
});
